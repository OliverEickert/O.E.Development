package train.brain.ticketapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends AppCompatActivity {

    private List<Ticket> liste;
    ListView lstAnzeige;
    MyTicketAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        liste = new ArrayList<>();

        lstAnzeige = this.findViewById(R.id.lst_anzeige);
        adapter = new MyTicketAdapter(this, R.layout.list_item_ticket, liste);
        lstAnzeige.setAdapter(adapter);

        try {
            getData();  //Asynchroner Prozess
        } catch (Exception e) {
            Log.d("MAIN EXCEPTION GET DATA", e.getMessage());
        }

        //gehört zum Main-Thread -- wird gleich gemacht
        Toast.makeText(this, "Wir können starten in der App", Toast.LENGTH_SHORT).show();


    }


    //eine Methode zum Abholen der Daten vom Server
    private void getData() throws ExecutionException, InterruptedException {
        //es wird ein paralleler Thread gebraucht
        ExecutorService service = Executors.newSingleThreadExecutor();

        //wir verwenden den service , um den Thread auszuführen und erhalten ein Ergebnis
        //Das Ergebnis erhalten wir in der Zukunft
        Future<String> future = service.submit(new HttpCallRequest());

        //wenn wir ein Ergebnis erhalten - es kann Exceptions geben
        service.submit(() -> {
            try {
                if(future.get()!=null)
                {
                    String json = future.get();
                    Log.d("FUTURE NACH CALL", json);

                    JsonArray feld = JsonParser.parseString(json).getAsJsonArray();
                    //für jede Zeile im Array
                    for (JsonElement element : feld) {
                        //wandle die Zeile in ein Ticket um
                        Ticket t = new Gson().fromJson(element, Ticket.class);
                        //füge der Liste hinzu
                        liste.add(t);
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter.notifyDataSetChanged();
                        }
                    });

                    for (Ticket t : liste) {
                        Log.d("DATEN TICKET", t.toString());
                    }
                } else
                {
                    Toast.makeText(this, "Keine Verbindung zum Server", Toast.LENGTH_SHORT).show();
                }
            } catch (ExecutionException e) {
                throw new RuntimeException(e);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });
        service.shutdown();
    }
}

