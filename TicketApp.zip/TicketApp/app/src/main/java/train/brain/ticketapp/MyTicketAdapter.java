package train.brain.ticketapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MyTicketAdapter extends ArrayAdapter<Ticket> {
    public MyTicketAdapter(@NonNull Context context, int resource, @NonNull List<Ticket> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list_item_ticket, parent, false);
        }

        Ticket wahl = getItem(position);

        TextView txtId = convertView.findViewById(R.id.txt_id);
        TextView txtBand = convertView.findViewById(R.id.txt_band);
        TextView txtPreis = convertView.findViewById(R.id.txt_preis);

        if(wahl != null) {
            txtId.setText(String.valueOf(wahl.getTid()));
            txtBand.setText(wahl.getBand());
            txtPreis.setText(String.valueOf(wahl.getPreis()));
        }

        convertView.setBackgroundColor(Color.WHITE);
        return convertView;
    }
}
