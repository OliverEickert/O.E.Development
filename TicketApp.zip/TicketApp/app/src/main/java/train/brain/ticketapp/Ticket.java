package train.brain.ticketapp;

public class Ticket {

    private int tid;
    private String band;
    private double preis;

    public Ticket(String band, double preis, int tid) {
        this.band = band;
        this.preis = preis;
        this.tid = tid;
    }

    public String getBand() {
        return band;
    }

    public void setBand(String band) {
        this.band = band;
    }

    public double getPreis() {
        return preis;
    }

    public void setPreis(double preis) {
        this.preis = preis;
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "band='" + band + '\'' +
                ", tid=" + tid +
                ", preis=" + preis +
                '}';
    }
}
