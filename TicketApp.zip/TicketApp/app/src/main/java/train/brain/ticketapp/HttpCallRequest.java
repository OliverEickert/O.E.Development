package train.brain.ticketapp;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Callable;

//generisches Interface
//Festlegen des Rückgabetyps (String - JSON vom Server)
public class HttpCallRequest implements Callable<String> {
    @Override
    public String call() throws Exception {
        String json = null;

        try
        {
            URL url = new URL("http://192.168.2.102:8080/musik/select.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000); //3 Sekunden warten maximal
            int status = conn.getResponseCode(); //StatusCode der Rückmeldung
            if(status == HttpURLConnection.HTTP_OK)
            {
                //daten sind gelandet in app :)
                //Einlesen in einen String
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                json = reader.readLine();
                reader.close();
            }
        }
        catch(Exception e)
        {
            Log.d("CALLABLE", e.getMessage());
            json = null; //ich habe leider keine Daten für die Main
        }

        return json;
    }
}
