package train.brain.artikeldata;

//ist ein Platzhalter für eine Methode, die bei Klick auf OK im Dialog ausgeführt wird

@FunctionalInterface
public interface IEventInsert
{
    void sendData(String bezeichnung, double preis, int menge, String farbe);
}
