package train.brain.artikeldata.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

//die Klasse implements das interface und damit alle Methoden, die in der MainActivity verwendet werden
public class Artikeldaten implements IData
{

    private ArrayList<Artikel> liste;

    public Artikeldaten()
    {
        liste = new ArrayList<>();
        liste.add(new Artikel("Hose", 10, 23.45, "schwarz"));
        liste.add(new Artikel("Hemd", 12, 19.99, "schwarz"));
        liste.add(new Artikel("Socken", 15, 5.89, "dunkelgrau"));
    }

    @Override
    public List<Artikel> select() {
        return liste;
    }

    @Override
    public List<Artikel> sort() {
        liste.sort(Comparator.comparing(Artikel::getBezeichnung));
        return null;
    }

    @Override
    public boolean insert(String bezeichnung, double preis, int menge, String farbe) {
        liste.add(new Artikel(bezeichnung, menge, preis ,farbe));
        return true;
    }

    @Override
    public boolean delete(String bezeichnung) {
        return liste.removeIf(a -> a.getBezeichnung().equals(bezeichnung));

    }

    @Override
    public boolean update(String bezeichnung, double preis) {
        return false;
    }

    @Override
    public boolean update(String bezeichnung, int menge) {
        return false;
    }
}
