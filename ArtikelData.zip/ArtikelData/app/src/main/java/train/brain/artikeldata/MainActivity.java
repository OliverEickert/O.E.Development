package train.brain.artikeldata;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.MenuProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import train.brain.artikeldata.model.Artikel;
import train.brain.artikeldata.model.Artikeldaten;
import train.brain.artikeldata.model.Datenbank;
import train.brain.artikeldata.model.IData;

public class MainActivity extends AppCompatActivity {

    ListView lstAnzeige;

    ArrayAdapter<Artikel> adapter;

    //Verbindung zum Interface im modell - Zugriff auf die Daten
    IData obj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        obj = new Datenbank(this, "mydata", null, 1);  //jetzt haben wir die Implementierung der Methoden aus dem interface IData

        //Control für die Anzeige einer Liste mit Daten
        lstAnzeige = this.findViewById(R.id.lst_anzeige);

        //legt fest, welche Daten angezeigt werden soll und WIE diese angezeigt werden sollen (layout)
        //3. Übergabe: von dem interface Aufruf der Methode select() -- gibt zurück eine List<Artikel>
        adapter = new MyArtikelAdapter(this, R.layout.list_item_artikel, obj.select());

        lstAnzeige.setAdapter(adapter);

        this.addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.activity_menu, menu);
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.menu_neu)
                {
                    //mach was
                    hinzuArtikelNeu();
                    return true; //ereignis behandelt
                }
                else if(menuItem.getItemId() == R.id.menu_sort)
                {
                    obj.sort();
                    adapter.notifyDataSetChanged();
                }
                return false;  //ereignis nicht behandelt
            }
        });

        lstAnzeige.setOnItemClickListener((adapterView, view, i, l) -> {

            Artikel wahl = (Artikel) adapterView.getItemAtPosition(i);

            //Toast.makeText(MainActivity.this, wahl.getBezeichnung(), Toast.LENGTH_SHORT).show();
            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
            dialog.setMessage(wahl.getBezeichnung() + " wirklich löschen? ");
            dialog.setPositiveButton("Ja", (dialogInterface, i1) -> {
                obj.delete(wahl.getBezeichnung());
                adapter.notifyDataSetChanged();
            });
            dialog.setNegativeButton("Nein", null);
            dialog.show();
        });

    }

    private void hinzuArtikelNeu()
    {
        MyInsertDialog dialog = new MyInsertDialog(this, (bezeichnung, preis, menge, farbe) -> {
            //obj ist die Schnittstelle zum Datenmodell mit der Artikelliste
            boolean result = obj.insert(bezeichnung, preis, menge, farbe);
            if(result)
            {
                Toast.makeText(MainActivity.this, "Artikel hinzugefügt", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
            }
            else
            {
                Toast.makeText(MainActivity.this, "Artikel nicht hinzugefügt", Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }
}