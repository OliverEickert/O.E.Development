package train.brain.artikeldata;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;

public class MyInsertDialog extends Dialog
{
    EditText editBezeichnung;
    EditText editPreis;
    EditText editMenge;
    EditText editFarbe;
    Button btnNeuOK;

    IEventInsert action;

    //Übergabe: 1. in welcher Activity wird dieser Dialog angezeigt
    //2. Übergabe: die MainActivity übergibt die Methode, die ausgeführt werden soll
    public MyInsertDialog(@NonNull Context context, IEventInsert action)
    {
        super(context); //Constructor Chaining
        this.action = action;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.dialog_insert);

        editBezeichnung = this.findViewById(R.id.edit_neu_bezeichnung);
        editPreis = this.findViewById(R.id.edit_neu_preis);
        editMenge = this.findViewById(R.id.edit_neu_menge);
        btnNeuOK = this.findViewById(R.id.btn_insert_ok);
        editFarbe = this.findViewById(R.id.edit_neu_farbe);

        btnNeuOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String bezeichnung = editBezeichnung.getText().toString();
                double preis = Double.parseDouble(editPreis.getText().toString());
                int menge = Integer.parseInt(editMenge.getText().toString());
                String farbe = editFarbe.getText().toString();

                //daten an MainActivity senden
                action.sendData(bezeichnung, preis, menge, farbe);
                dismiss();
            }
        });


    }
}
