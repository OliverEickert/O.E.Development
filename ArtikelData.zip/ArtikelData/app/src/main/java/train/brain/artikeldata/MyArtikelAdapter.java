package train.brain.artikeldata;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import train.brain.artikeldata.model.Artikel;

//übernimmt eine Liste von Artikeln und erstellt für jedes Objekt in der Liste
//ein Layout (list_item_artikel.xml) und fügt dieses dem ListView in der MainActivity hinzu
public class MyArtikelAdapter extends ArrayAdapter<Artikel> {

    private Context context;  //wo befindet sich der ListView, in welchem die Artikel angezeigt werden
                              //die Variable erhalten wir im Constructor und brauchen wir in getView()

    //referenzen zu den TextViews für die Anzeige der Eigenschaften eines Artikels
    TextView txtBezeichnung;
    TextView txtPreis;
    TextView txtMenge;
    TextView txtFarbe;

    //Übergabe: 1. in welcher Activity soll der Item angezeigt werden  (in welcher Activity befindet sich mein ListView)
    //Übergabe 2.: welche layout-Datei soll verwendet werden für die Anzeige eines Artikels
    //Übergabe 3: welche Daten sollen in dem listView angezeigt werden
    public MyArtikelAdapter(@NonNull Context context, int resource, @NonNull List<Artikel> liste) {
        super(context, resource, liste); //Constructor-Chaining
        this.context = context;
    }

    //hole den Artikel an der aktuellen Position
    @Nullable
    @Override
    public Artikel getItem(int position) {
        return super.getItem(position);
    }

    //layout definieren für einen Artikel
    //Übergabe: 1. die Position des anzuzeigenden Artikels in der Liste
    //Übergabe 2.: eine Referenz zum Layout für den Artikel (ListItem)
    //Übergabe 3.: wo soll der Artikel angezeigt werden ( ListView in der MainActivity)
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //wenn kein Layout für die Anzeige des Artikels vorhanden
        if(convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_artikel, parent, false);
        }

        //der Artikel, der angezeigt werden soll
        Artikel obj = getItem(position);

        txtBezeichnung = convertView.findViewById(R.id.txt_item_bezeichnung);
        txtBezeichnung.setText(obj.getBezeichnung());

        txtPreis = convertView.findViewById(R.id.txt_item_preis);
        txtPreis.setText(String.valueOf(obj.getPreis()));

        txtMenge = convertView.findViewById(R.id.txt_item_menge);
        txtMenge.setText(String.valueOf(obj.getMenge()));

        txtFarbe =  convertView.findViewById(R.id.txt_item_farbe);
        txtFarbe.setText(obj.getFarbe());

        return convertView;
    }
}
