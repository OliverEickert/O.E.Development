package train.brain.artikeldata.model;

public class Artikel {

    private String bezeichnung;
    private double preis;
    private int menge;
    private String farbe;

    //Konstruktor nur innerhalb des pakets verwendbar
    //es darf kein Objekt außerhalb dieses Paketes erzeugt werden
    //default-Zugriffsrecht
    Artikel(String bezeichnung, int menge, double preis, String farbe) {
        this.bezeichnung = bezeichnung;
        this.menge = menge;
        this.preis = preis;
        this.farbe = farbe;
    }

    public String getFarbe() {
        return farbe;
    }

    void setFarbe(String farbe) {
        this.farbe = farbe;
    }

    void setBezeichnung(String bezeichnung) {
        this.bezeichnung = bezeichnung;
    }

    void setMenge(int menge) {
        this.menge = menge;
    }

    void setPreis(double preis) {
        this.preis = preis;
    }

    public String getBezeichnung() {
        return bezeichnung;
    }

    public int getMenge() {
        return menge;
    }

    public double getPreis() {
        return preis;
    }

    @Override
    public String toString() {
        return "Artikel{" +
                "bezeichnung='" + bezeichnung + '\'' +
                ", preis=" + preis +
                ", menge=" + menge +
                '}';
    }
}
