package train.brain.artikeldata.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Datenbank extends SQLiteOpenHelper implements IData {

    //Die Datenbank verwaltet eine Liste mit Artikeln
    // es gibt in der gesamten APP genau eine Referenz zu einer Liste von Artikeln
    private ArrayList<Artikel> liste = new ArrayList<>();

    //von der Oberklasse
    //Übergabe: 1 - welche Activity verwendet die DAtenbank
    //Übergabe: 2 - name der Datenbank / name der Datei
    //Übergabe: 3 - Zugriff auf Tabellen / uni- oder bidirektional  (Abhängig von der Anwendung)
    //Übergabe: 4 - Versionsnummer  (wenn Nummer sich ändert, dann Methode upgrade aufgerufen und create noch mal gemacht)
    public Datenbank(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "mydata", factory, 1);
        //this.getWritableDatabase(); //erstellen einer Verbindung zur Datenbank -- das ruft onCreate() auf
    }

    //wird einmalig ausgeführt
    //bei installation und 1. Ausführung wird die methode ausgeführt
    //erstellt eine Datei mit dem Namen der Datenbank PLUS die Kommandos
    //dann NIE WIEDER, außer die lösche die Daten der App
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table artikel (aid integer primary key autoincrement, bezeichnung varchar(50), preis double, menge int, farbe varchar(40))");
        sqLiteDatabase.execSQL("insert into artikel (bezeichnung, preis, menge, farbe) values ('Hose', 23.45, 10, 'schwarz')");
        sqLiteDatabase.execSQL("insert into artikel (bezeichnung, preis, menge, farbe) values ('hemd', 19.99, 12, 'dunkelgrau')");

    }

    //wird intern ausgeführt
    //wenn die Versionsnummern sich unterscheiden
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //Wenn die Versionsnummern sich unterscheiden
        if(i != i1)
        {
            sqLiteDatabase.execSQL("drop table artikel");
            onCreate(sqLiteDatabase);
        }
    }

    @Override
    public List<Artikel> select() {

        SQLiteDatabase db = this.getWritableDatabase();
        //Rückgabe: zeiger an den Anfang der Tabelle (steht VOR dem 1. Datansatz)
        Cursor cursor = db.rawQuery("select * from artikel", null);

        //wir löschen den Inhalt der Liste
        liste.clear();

        //solange noch Daten in der Tabelle geht der Cursor zur nächsten zeile in der Tabelle
        while(cursor.moveToNext())
        {
            String bezeichnung = cursor.getString(1);//0: index des Feldes in der zeile (aid -- 1. Spalte in der Zeile)
            double preis = cursor.getDouble(2);
            int menge = cursor.getInt(3);
            String farbe = cursor.getString(4);

            Artikel neu = new Artikel( bezeichnung,  menge, preis, farbe);

            liste.add(neu);
        }
        cursor.close();
        return liste;
    }

    @Override
    public List<Artikel> sort() {
        SQLiteDatabase db = this.getWritableDatabase();
        //Rückgabe: zeiger an den Anfang der Tabelle (steht VOR dem 1. Datansatz)
        Cursor cursor = db.rawQuery("select * from artikel order by preis asc", null);

        //wir löschen den Inhalt der Liste
        liste.clear();

        //solange noch Daten in der Tabelle geht der Cursor zur nächsten zeile in der Tabelle
        while(cursor.moveToNext())
        {
            String bezeichnung = cursor.getString(1);//0: index des Feldes in der zeile (aid -- 1. Spalte in der Zeile)
            double preis = cursor.getDouble(2);
            int menge = cursor.getInt(3);
            String farbe = cursor.getString(4);

            Artikel neu = new Artikel( bezeichnung,  menge, preis, farbe);

            liste.add(neu);
        }
        cursor.close();
        return liste;
    }

    @Override
    public boolean insert(String bezeichnung, double preis, int menge, String farbe)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        //? - Platzhalter für den variablen Wert (der in DB eingetragen werden soll
        //Sicherheit: SQL-Injection
        try {
            db.execSQL("insert into artikel (bezeichnung, preis,menge, farbe) values (?,?,?,?)", new String[]{bezeichnung, String.valueOf(preis), String.valueOf(menge), farbe});
            //select();
            liste.add(new Artikel(bezeichnung, menge, preis, farbe));
            return true;
        }
        catch(Exception e)
        {
            Log.d("INSERT DB", e.getMessage());
            return false;
        }
    }

    @Override
    public boolean delete(String bezeichnung) {
        SQLiteDatabase db = this.getWritableDatabase();
        try
        {
            db.execSQL("delete from artikel where bezeichnung = ?", new String[]{bezeichnung});
            select();
            return true;
        }
        catch(Exception e)
        {
            Log.d("DELETE DB", e.getMessage());
            return false;
        }
    }

    @Override
    public boolean update(String bezeichnung, double preis) {
        return false;
    }

    @Override
    public boolean update(String bezeichnung, int menge) {
        return false;
    }
}
