package train.brain.artikeldata.model;


import java.util.List;

//deklariert alle Methoden für die Verwaltung einer Liste mit Artikeln
//alle Methoden sind per Definition public (und abstrakt)
public interface IData {

    List<Artikel> select();
    List<Artikel> sort();
    boolean insert(String bezeichnung, double preis, int menge, String farbe);
    boolean delete(String bezeichnung);
    boolean update(String bezeichnung, double preis);
    boolean update(String bezeichnung, int menge);
}
