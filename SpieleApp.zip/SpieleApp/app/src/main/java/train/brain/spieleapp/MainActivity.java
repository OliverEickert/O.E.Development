package train.brain.spieleapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuProvider;

import java.util.Random;

import train.brain.spieleapp.model.Datenbank;


public class MainActivity extends AppCompatActivity {

    Datenbank db;

    private TextView txtZeit;
    private TextView txtTreffer;
    private GridLayout grid;
    private Button btnStart;

    private int treffer;

    //initialisierung Zufallszahlengenerator
    Random rand = new Random();

    private boolean isStopped;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        db = new Datenbank(this, "stat", null, 1);

        treffer = 0;

        txtZeit = this.findViewById(R.id.txt_zeit);
        txtTreffer = this.findViewById(R.id.txt_treffer);
        grid = this.findViewById(R.id.grid);
        btnStart = this.findViewById(R.id.btn_start);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = btnStart.getText().toString();
                if(text.equals("Start")) {
                    startenSpiel();
                }
                else
                {
                    stoppenSpiel();
                }
            }
        });

        this.addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.activity_menu, menu);
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.menu_stat)
                {
                    //Activity starten
                    Intent intent = new Intent(MainActivity.this, StatisticActivity.class);
                    startActivity(intent);
                }
                return false;
            }
        });

        //jedem Button in dem grid fügen wir ein Ereignis onClick() hinzu
        for(int i = 0; i< 9; i++)
        {
            Button btn = (Button)grid.getChildAt(i);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {  //Übergabe: view - auf welchen Button wurde geklickt
                    boolean markiert = (boolean) view.getTag();
                    if(markiert)
                    {
                        markierenButtons();
                        treffer++;
                        txtTreffer.setText("Treffer: " + treffer);
                    }
                }
            });
        }

        markierenButtons();
    }

    private void markierenButtons()
    {
        //für jeden Button in dem Grid
        for(int i = 0; i < 9; i++)
        {
            grid.getChildAt(i).setTag(false); //kein Button ist markiert
            grid.getChildAt(i).setBackgroundColor(Color.LTGRAY);
        }

        int index = rand.nextInt(9); //eine Zufallszahl erzeugen (index)
        grid.getChildAt(index).setTag(true);
        //Test
        grid.getChildAt(index).setBackgroundColor(Color.MAGENTA);
    }

    private void startenSpiel()
    {
        Timer timer = new Timer();
        new Thread(timer).start();  //timer wird parallel ausgeführt
        //Thread ist in ThreadPool und ProcessScheduler entscheidet, wann ausgeführt
        isStopped = false;
        for(int i = 0; i < 9; i++)
        {
            grid.getChildAt(i).setEnabled(true);
        }

        treffer = 0;
        txtTreffer.setText("Treffer: " + treffer);
        btnStart.setText("Stopp");
        markierenButtons();
    }

    private void stoppenSpiel()
    {
        btnStart.setText("Start");
        isStopped = true;
        //alle Buttons disablen - ich kann nicht mehr darauf klicken
        for(int i = 0; i < 9; i++)
        {
            grid.getChildAt(i).setEnabled(false);
        }
        db.insert(treffer);
    }

    //wir definieren eine Klasse für den parallelen Thread
    //ist eine inner class von MainActivity
    //kann damit auf alle Instanzvariablen und Methoden der Klasse MainActivity zugreifen
    class Timer implements Runnable
    {
        int i = 60;
        @Override
        public void run() {

            while(!isStopped && i > -1)
            {
                //Only the original thread that created a view hierarchy can touch its views.
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        txtZeit.setText(String.valueOf(i));
                    }
                });

                try {
                    Thread.sleep(1000); //Schlafen
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                i--;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    stoppenSpiel();
                }
            });

        }
    }
}