package train.brain.spieleapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

import train.brain.spieleapp.model.Eintrag;

public class MyEintragAdapter extends ArrayAdapter<Eintrag> {

    public MyEintragAdapter(@NonNull Context context, int resource, @NonNull List<Eintrag> objects) {
        super(context, resource, objects);
    }

    @Nullable
    @Override
    public Eintrag getItem(int position) {
        return super.getItem(position);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //wenn noch kein Layout für den anzuzeigenden Eintrag vorhanden
        if(convertView == null)
        {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list_item_eintrag, parent, false); //parent ist ListView
        }

        Eintrag wahl = getItem(position);

        //nimm die TextViews im Layout und trage ein
        TextView txtId = convertView.findViewById(R.id.txt_item_id);
        txtId.setText(String.valueOf(wahl.getId()));

        TextView txtTreffer = convertView.findViewById(R.id.txt_item_treffer);
        txtTreffer.setText(String.valueOf(wahl.getTreffer()));

        TextView txtZeit = convertView.findViewById(R.id.txt_item_zeit);
        txtZeit.setText(wahl.getZeit().toString());

        return convertView;
    }
}
