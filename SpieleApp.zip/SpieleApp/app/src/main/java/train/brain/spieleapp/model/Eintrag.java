package train.brain.spieleapp.model;

import java.time.LocalDateTime;

public class Eintrag
{
    private int id;
    private int treffer;
    private LocalDateTime zeit;

    public Eintrag(int id, int treffer, LocalDateTime zeit) {
        this.id = id;
        this.treffer = treffer;
        this.zeit = zeit;
    }

    public int getId() {
        return id;
    }

    public LocalDateTime getZeit() {
        return zeit;
    }

    public int getTreffer() {
        return treffer;
    }
}
