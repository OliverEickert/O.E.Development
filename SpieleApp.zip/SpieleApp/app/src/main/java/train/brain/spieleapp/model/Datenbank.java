package train.brain.spieleapp.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Datenbank extends SQLiteOpenHelper {

    public Datenbank(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        this.getWritableDatabase(); //damit rufen wir onCreate auf
    }

    //wird aufgerufen, wenn die Datenbank noch nicht existiert (INTERN)
    //geprüft wird erst, wenn man auf die Datenbank zugreifen möchte
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("create table statistik (sid integer primary key autoincrement, treffer int, zeit datetime)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insert(int treffer)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("insert into statistik (treffer, zeit) values (?, datetime('now'))", new String[]{String.valueOf(treffer)});
    }

    public List<Eintrag> select()
    {
        List<Eintrag> liste = new ArrayList<>();

        SQLiteDatabase db = this.getWritableDatabase();

        //zeiger an den Anfang der Ergebnistabelle
        Cursor cursor = db.rawQuery("select sid, treffer, zeit from statistik order by treffer", null);
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        while(cursor.moveToNext())
        {
            int id = cursor.getInt(0);
            int treffer = cursor.getInt(1);
            LocalDateTime zeit = LocalDateTime.parse(cursor.getString(2), format);

            liste.add(new Eintrag(id, treffer, zeit));
        }

        cursor.close();
        return liste;
    }
}
