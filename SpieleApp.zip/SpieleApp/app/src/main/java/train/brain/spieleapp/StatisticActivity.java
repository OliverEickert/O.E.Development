package train.brain.spieleapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.MenuProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import train.brain.spieleapp.model.Datenbank;

public class StatisticActivity extends AppCompatActivity {

    private ListView lstAnzeige;
    MyEintragAdapter adapter;
    Datenbank db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_statistic);
        db = new Datenbank(this, "stat", null, 1);

        lstAnzeige = this.findViewById(R.id.lst_anzeige);
        adapter = new MyEintragAdapter(this, R.layout.list_item_eintrag, db.select());
        lstAnzeige.setAdapter(adapter);

        this.addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menuInflater.inflate(R.menu.statistic_menu, menu);
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                if(menuItem.getItemId() == R.id.menu_back)
                {
                    Intent intent = new Intent(StatisticActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                return false;
            }
        });
    }
}